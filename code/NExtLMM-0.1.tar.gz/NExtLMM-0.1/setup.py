from setuptools import setup, find_packages


setup(


    name="NExtLMM",


    version="0.1",


    packages=find_packages(),


    install_requires=['numpy', 'pandas', 'scipy'],


    author="Zhibin Pu, Shijia Wang and Shufei Ge",


    author_email="puzhb2022@shanghaitech.edu.cn",


    description="A novel framework for genome-wise association test",


    url="https://github.com/ZhibinPU/NExt-LMM",


    classifiers=[


        "Programming Language :: Python :: 3",


        "License :: OSI Approved :: MIT License",


        "Operating System :: OS Independent",


    ],


    python_requires='>=3.7',


)